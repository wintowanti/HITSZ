# -*-encoding=UTF-8 -*-
print "加载 path_y 成功"
source_input = "./project2_TrainingSet7000"
new_name_dict = "./dict/name_y.txt"
famous_name_dict = "./dict/famous_name.txt"
joey_name_dict = "./dict/joey_name.txt"
